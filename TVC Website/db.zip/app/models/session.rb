class Session < ActiveRecord::Base
end
