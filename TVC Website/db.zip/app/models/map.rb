class Map < ActiveRecord::Base
  belongs_to :question
end
